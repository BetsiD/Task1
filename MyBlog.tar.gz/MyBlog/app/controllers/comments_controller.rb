class CommentsController < ApplicationController
	def create
		@comment = Comment.new(comment_params)
   		@comment.save
      		redirect_to blog_path(id:@comment.blog_no)
	end

	def comment_params
   		params.require(:comment).permit(:comment_text, :blog_no)
	end
end
