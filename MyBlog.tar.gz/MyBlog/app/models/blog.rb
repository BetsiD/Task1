class Blog < ApplicationRecord
		
end
