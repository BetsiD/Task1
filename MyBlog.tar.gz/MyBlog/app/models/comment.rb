class Comment < ApplicationRecord
			
end
