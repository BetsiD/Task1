Rails.application.routes.draw do
	resources:comments
  	resources:blogs
end
